
import { Component, Injectable, OnInit } from '@angular/core';
import { SelectItemGroup} from 'primeng/api'; 
import { HttpClient } from '@angular/common/http';
import { MenuItem } from "primeng/api";
import { SelectItem } from "primeng/api";
import { FilterService } from 'primeng/api';
import {CalendarModule} from 'primeng/calendar';

interface City {
    name: string,
    code: string
}

interface Country {
    name: string,
    code: string
}

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
  
  })

  export class Page1Component implements OnInit{
    
    value: any;
    date1!: Date;

    date2!: Date;

    date3!: Date;

    date4!: Date;

    date5!: Date;

    date6!: Date;

    date7!: Date;

    date8!: Date;

    date9!: Date;

    date10!: Date;

    date11!: Date;

    date12!: Date;

    date13!: Date;

    date14!: Date;

    dates!: Date[];

    rangeDates!: Date[];

    minDate!: Date;

    maxDate!: Date;

    invalidDates!: Array<Date>;

    countries: any[] = [];

    selectedCity1: any;

    selectedCity2: any;

    checked1: boolean = false;

    checked2: boolean = true;
    disabled: boolean = true;

    value1!: string;

    value2!: string;

    value3!: string;

    value4!: string;

    value5: string = 'Disabled';
    value6!: string;

    blockSpecial: RegExp = /^[^<>*!]+$/ 
    
    blockSpace: RegExp = /[^\s]/; 
    
    ccRegex: RegExp = /[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{4}$/; 
    
    cc!: string; 

    ngOnInit() 
    {
        let today = new Date();
        let month = today.getMonth();
        let year = today.getFullYear();
        let prevMonth = (month === 0) ? 11 : month -1;
        let prevYear = (prevMonth === 11) ? year - 1 : year;
        let nextMonth = (month === 11) ? 0 : month + 1;
        let nextYear = (nextMonth === 0) ? year + 1 : year;
        this.minDate = new Date();
        this.minDate.setMonth(prevMonth);
        this.minDate.setFullYear(prevYear);
        this.maxDate = new Date();
        this.maxDate.setMonth(nextMonth);
        this.maxDate.setFullYear(nextYear);

        let invalidDate = new Date();
        invalidDate.setDate(today.getDate() - 1);
        this.invalidDates = [today,invalidDate];
    
            // Calander end
    
        this.countries = [
          {
            
              name: 'Australia',
              code: 'AU',
              states: [
                  {
                      name: 'New South Wales',
                      cities: [
                          {cname: 'Sydney', code: 'A-SY'},
                          {cname: 'Newcastle', code: 'A-NE'},
                          {cname: 'Wollongong', code: 'A-WO'}
                      ]
                  },
                  {
                      name: 'Queensland',
                      cities: [
                          {cname: 'Brisbane', code: 'A-BR'},
                          {cname: 'Townsville', code: 'A-TO'}
                      ]
                  },
                  
              ]
          },
          {
              name: 'Canada', 
              code: 'CA',
              states: [
                  {
                      name: 'Quebec',
                      cities: [
                          {cname: 'Montreal', code: 'C-MO'},
                          {cname: 'Quebec City', code: 'C-QU'}
                      ]
                  },
                  {
                      name: 'Ontario',
                      cities: [
                          {cname: 'Ottawa', code: 'C-OT'},
                          {cname: 'Toronto', code: 'C-TO'}
                      ]
                  },
                  
              ]
          },
          {
              name: 'United States',
              code: 'US',
              states: [
                  {
                      name: 'California',
                      cities: [
                          {cname: 'Los Angeles', code: 'US-LA'},
                          {cname: 'San Diego', code: 'US-SD'},
                          {cname: 'San Francisco', code: 'US-SF'}
                      ]
                  },
                  {
                      name: 'Florida',
                      cities: [
                          {cname: 'Jacksonville', code: 'US-JA'},
                          {cname: 'Miami', code: 'US-MI'},
                          {cname: 'Tampa', code: 'US-TA'},
                          {cname: 'Orlando', code: 'US-OR'}
                      ]
                  },
                  {
                      name: 'Texas',
                      cities: [
                          {cname: 'Austin', code: 'US-AU'},
                          {cname: 'Dallas', code: 'US-DA'},
                          {cname: 'Houston', code: 'US-HO'}
                      ]
                  }
              ]
          }
      ];
  

    }
  
// Chips
    // Chips
  values1: string[] = [];
    
    values2: string[] = [];

    values3: string[] = [];

    color1!: string;
    
    color2: string = '#1976D2';


    




}

        



