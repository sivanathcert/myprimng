import { FilterService } from 'primeng/api';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Page1Component } from './Page1Component/page1.component';
import { Page2Component } from './Page2Component/page2.component';
import { Page3Component } from './Page3Component/page3.component';
import { Page4Component } from './Page4Component/page4.component';
import { Page5Component } from './Page5Component/page5.component';
import { Page6Component } from './Page6Component/page6.component';
import { Page7Component } from './Page7Component/page7.component';
import { AccordionModule } from 'primeng/accordion';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { PanelMenuModule } from 'primeng/panelmenu';
import { CommonModule } from '@angular/common';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms'
import {CalendarModule} from 'primeng/calendar';
import {TabViewModule} from 'primeng/tabview';
import {CascadeSelectModule} from 'primeng/cascadeselect';
import { DropdownModule } from 'primeng/dropdown';
import {CheckboxModule} from 'primeng/checkbox';
import {ChipsModule} from 'primeng/chips';
import {ColorPickerModule} from 'primeng/colorpicker';
import {EditorModule} from 'primeng/editor';
import { ReactiveFormsModule, DefaultValueAccessor, ControlValueAccessor } from '@angular/forms';
import { RadioButtonModule } from 'primeng/radiobutton';
import {InputSwitchModule} from 'primeng/inputswitch';
import {InputTextModule} from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import {RippleModule} from 'primeng/ripple';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {InputNumberModule} from 'primeng/inputnumber';
import {KnobModule} from 'primeng/knob';
import {KeyFilterModule} from 'primeng/keyfilter';
import {ListboxModule} from 'primeng/listbox';
import {MultiSelectModule} from 'primeng/multiselect';
import {PasswordModule} from 'primeng/password';
import {RatingModule} from 'primeng/rating';
import {SliderModule} from 'primeng/slider';
import {SelectButtonModule} from 'primeng/selectbutton';
import {ToggleButtonModule} from 'primeng/togglebutton';
import {TreeSelectModule} from 'primeng/treeselect';
import {TriStateCheckboxModule} from 'primeng/tristatecheckbox';
import {SplitButtonModule} from 'primeng/splitbutton';

@NgModule({
  declarations: [
    Page7Component,
    Page6Component,
    Page5Component,
    Page4Component,
    Page3Component,
    Page2Component,
    Page1Component,
    AppComponent
  ],  
  imports: [ 
    SplitButtonModule,
    TriStateCheckboxModule,
    TreeSelectModule,
    ToggleButtonModule,
    SelectButtonModule,
    SliderModule,
    RatingModule,
    PasswordModule,
    MultiSelectModule,
    ListboxModule,
    KeyFilterModule,
    KnobModule,
    InputNumberModule,
    InputTextareaModule,
    InputSwitchModule, 
    InputTextModule,
    ButtonModule,
    RippleModule,
    RadioButtonModule,
    ReactiveFormsModule,  
    EditorModule,
    AccordionModule,
    ColorPickerModule,
    ChipsModule,
    CheckboxModule,
    DropdownModule,
    CascadeSelectModule,
    CommonModule,
    TabViewModule,
    CalendarModule,
    PanelMenuModule,
    HttpClientTestingModule,
    HttpClientModule,
    FormsModule,
    AutoCompleteModule,
    BrowserAnimationsModule,
    AccordionModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    DefaultValueAccessor,
    
    FilterService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
