import { SelectItem } from 'primeng/api';
import { SelectItemGroup } from 'primeng/api';
import { HttpClient } from '@angular/common/http';
import { Component, Injectable } from '@angular/core';

@Component({
  selector: 'app-page3',
  templateUrl: './page3.component.html',
  styleUrls: ['./page3.component.css']
})

export class Page3Component {
  text1: string = '<div>Hello World!</div><div>PrimeNG <b>Editor</b> Rocks</div><div><br></div>';    
  text2!: string;
  value1: number = 42723;

    value2: number = 58151;

    value3: number = 2351.35;

    value4: number = 50;

    value5: number = 151351;

    value6: number = 115744;

    value7: number = 635524;

    value8: number = 732762;

    value9: number = 1500;

    value10: number = 2500;

    value11: number = 4250;

    value12: number = 5002;

    value13: number = 20;

    value14: number = 50;

    value15: number = 10;

    value16: number = 20;

    value17: number = 20;

    value18: number = 10.50;

    value19: number = 25;

    value20: number = 50;
}

