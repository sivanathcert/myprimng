import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Page1Component } from './Page1Component/page1.component';
import { Page2Component } from './Page2Component/page2.component'; 
import { Page3Component } from './Page3Component/page3.component';
import { Page4Component } from './Page4Component/page4.component';
import { Page5Component } from './Page5Component/page5.component';
import { Page6Component } from './Page6Component/page6.component';
import { Page7Component } from './Page7Component/page7.component';

const routes: Routes = [
  {
    path:'Page1',
    component: Page1Component
  },
  {
    path:'Page2',
    component: Page2Component
  },
  {
    path:'Page3',
    component: Page3Component
  },
  {
    path:'Page4',
    component: Page4Component
  },
  {
    path:'Page5',
    component: Page5Component
  },
  {
    path:'Page6',
    component: Page6Component
  },
  {
    path:'Page7',
    component: Page7Component
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
