import { FilterService, SelectItemGroup } from 'primeng/api';
import { Component, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Inject } from '@angular/core';
import { HttpParams } from '@angular/common/http';



@Component({
  selector: 'app-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css']
})

export class Page2Component {
    category: any
    valueIconLeft: any;
    valueIconRight: any;
    value1: any;
    value2: any;
    value3: any;
    value4: any;
    value5: any;
    value6: any;
    value7: any;
    value8: any;
    value9: any;
    value10: any;
    value11: any;

    val1!: number;

    val2: number = 3;

    val3: number = 5;

    val4: number = 5;

    val5!: number;

    msg!: string;

  selectedCities: string[] = [];

    selectedCategories: any[] = ['Technology', 'Sports'];

    categories: any[] = [{name: 'Accounting', key: 'A'}, {name: 'Marketing', key: 'M'}, {name: 'Production', key: 'P'}, {name: 'Research', key: 'R'}];

    checked: boolean = false;

    ngOnInit() {
        this.selectedCategories = this.categories.slice(1,3);
    }

}






/*
@Injectable()
export class CountryService {

    constructor(private http: HttpClient) {}

    getCountries() {
      return this.http.get('showcase/resources/data/countries.json')
                  .toPromise()
                  .then(res => <any[]> res.json().data)
                  .then(data => { return data; });
    }
}

export class Page2Component {

  
  selectedCountry: any;

  selectedCity: any;

  selectedItem: any;

  countries: any[] = [];

  items: any[] = [];

  filteredCountries: any[] = [];

  filteredItems: any[] = [];

  selectedCountries: any[] = [];

  selectedCountryAdvanced: any[] = [];

  filteredBrands: any[] = [];

  groupedCities: SelectItemGroup[] = [];

  filteredGroups: any[] = [];

  

  constructor(private countryService: CountryService, private filterService: FilterService) { }
  ngOnInit() {
    this.countryService.getCountries().then((countries: any[]) => {
        this.countries = countries;
    });

    this.groupedCities = [
      {
          label: 'Germany', value: 'de',
          items: [
              {label: 'Berlin', value: 'Berlin'},
              {label: 'Frankfurt', value: 'Frankfurt'},
              {label: 'Hamburg', value: 'Hamburg'},
              {label: 'Munich', value: 'Munich'}
          ]
      },
      {
          label: 'USA', value: 'us',
          items: [
              {label: 'Chicago', value: 'Chicago'},
              {label: 'Los Angeles', value: 'Los Angeles'},
              {label: 'New York', value: 'New York'},
              {label: 'San Francisco', value: 'San Francisco'}
          ]
      },
      {
          label: 'Japan', value: 'jp',
          items: [
              {label: 'Kyoto', value: 'Kyoto'},
              {label: 'Osaka', value: 'Osaka'},
              {label: 'Tokyo', value: 'Tokyo'},
              {label: 'Yokohama', value: 'Yokohama'}
          ]
      }
  ];

  this.items = [];
  for (let i = 0; i < 10000; i++) {
      this.items.push({label: 'Item ' + i, value: 'Item ' + i});
  }
}

filterCountry(event: { query: any; }) {
  //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
  let filtered : any[] = [];
  let query = event.query;

  for(let i = 0; i < this.countries.length; i++) {
      let country = this.countries[i];
      if (country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(country);
      }
  }

  this.filteredCountries = filtered;
}

filterItems(event: { query: any; }) {
  //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
  let filtered : any[] = [];
  let query = event.query;

  for(let i = 0; i < this.items.length; i++) {
      let item = this.items[i];
      if (item.label.toLowerCase().indexOf(query.toLowerCase()) == 0) {
          filtered.push(item);
      }
  }

  this.filteredItems = filtered;
}

filterGroupedCity(event: { query: any; }) {
  let query = event.query;
  let filteredGroups = [];

  for (let optgroup of this.groupedCities) {
      let filteredSubOptions = this.filterService.filter(optgroup.items, ['label'], query, "contains");
      if (filteredSubOptions && filteredSubOptions.length) {
          filteredGroups.push({
              label: optgroup.label,
              value: optgroup.value,
              items: filteredSubOptions
          });
      }
  }

  this.filteredGroups = filteredGroups;
}

}
*/